/* This file is part of hwzip from https://www.hanshq.net/zip.html
   It is put in the public domain; see the LICENSE file for details. */

#ifndef HAMLET_H
#define HAMLET_H

#include <stdint.h>

extern const uint8_t hamlet[204908];

#endif
