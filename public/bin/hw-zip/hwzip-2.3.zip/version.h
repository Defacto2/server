/* This file is part of hwzip from https://www.hanshq.net/zip.html
   It is put in the public domain; see the LICENSE file for details. */

#ifndef VERSION_H
#define VERSION_H

#define VERSION "2.3"

#endif
