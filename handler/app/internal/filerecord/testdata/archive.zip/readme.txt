A test text file.
